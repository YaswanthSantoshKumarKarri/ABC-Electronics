package com.example.abcelectronics.entities;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.persistence.UniqueConstraint;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
//@Data
//@AllArgsConstructor
//@NoArgsConstructor
@Table(name="client")
public class Client {

	
	@Id
	@Column(unique = true)
	private String clientId;
	private String password;
	private String address;
	@Column(unique = true)
	private Long phoneNumber;
	
	public Client(Long phoneNumber, String clientId, String password, String address) {
		super();
		this.phoneNumber = phoneNumber;
		this.clientId = clientId;
		this.password = password;
		this.address = address;
	}
	public Client() {
		super();
	}
	public Long getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(Long phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	public String getClientId() {
		return clientId;
	}
	public void setClientId(String clientId) {
		this.clientId = clientId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	@Override
	public String toString() {
		return "Client [phoneNumber=" + phoneNumber + ", clientId=" + clientId + ", password=" + password + ", address="
				+ address + "]";
	}
	
	
}
