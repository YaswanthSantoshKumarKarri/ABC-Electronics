package com.example.abcelectronics.service;

import org.springframework.stereotype.Service;

import com.example.abcelectronics.entities.Engineer;

@Service
public interface AdminService {

	Engineer addEngineer(Engineer engineerData);

}
