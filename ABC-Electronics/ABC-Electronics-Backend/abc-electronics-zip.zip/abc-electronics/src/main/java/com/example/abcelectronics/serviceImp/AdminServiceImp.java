package com.example.abcelectronics.serviceImp;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.abcelectronics.entities.Engineer;
import com.example.abcelectronics.repos.AdminRepos;
import com.example.abcelectronics.service.AdminService;

@Service
public class AdminServiceImp implements AdminService {

	@Autowired
	private AdminRepos adminRepos;
	
	@Override
	public Engineer addEngineer(Engineer engineerData) {
		// TODO Auto-generated method stub
		return adminRepos.save(engineerData);
	}

}
