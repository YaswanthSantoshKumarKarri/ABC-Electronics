package com.example.abcelectronics.controller;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.example.abcelectronics.entities.Client;
import com.example.abcelectronics.entities.Engineer;
import com.example.abcelectronics.service.ClientService;

@RestController
@RequestMapping("/API/Client")
public class ClientController {

	@Autowired
	private ClientService clientService;
	
	@PostMapping("/create")
	public Client saveClient(@RequestBody Client clientData) {
		return clientService.saveClient(clientData);
	}
	
	@GetMapping("/{clientId}")
	public Optional<Client> getClientById(@PathVariable String clientId) {
		return clientService.getClientById(clientId);
	}
	@GetMapping("/engineer/{engineerId}")
	public Optional<Engineer> getEngineerById(@PathVariable int engineerId) {
		return clientService.getEngineerById(engineerId);
	}
	@GetMapping("/engineer/domain/{domain}")
	public Optional<Engineer> getEngineerByDomain(@PathVariable String domain) {
		return clientService.getEngineerByDomain(domain);
	}
	
}
