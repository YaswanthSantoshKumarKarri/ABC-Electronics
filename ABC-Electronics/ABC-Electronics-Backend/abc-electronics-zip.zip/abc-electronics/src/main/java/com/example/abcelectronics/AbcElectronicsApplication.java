package com.example.abcelectronics;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AbcElectronicsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AbcElectronicsApplication.class, args);
	}

}
