package com.example.abcelectronics.repos;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.abcelectronics.entities.Engineer;

public interface AdminRepos extends JpaRepository<Engineer, Integer> {

	Optional<Engineer> findByDomain(String domain);

}
